<?php
    const BASE_URL = "http://localhost/pos_mvc/";
    const HOST = "localhost";
    const BD = "datatables_vue";
    const DB_USER = "root";
    const PASS = "";
    const CHARSET = "charset=utf8";
?>