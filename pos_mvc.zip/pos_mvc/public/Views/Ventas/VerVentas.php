<?php
require_once "Assets/pdf/fpdf.php";
$total = 0.00;
$pdf = new FPDF('P', 'mm', array(105 , 148));
$pdf->AddPage();
$pdf->setFont('Arial', 'B', 14);
$pdf->setTitle("Reporte de Venta");
$pdf->image(base_url().'Assets/img/GRAFIHERRAJES.jpg', 8, 10, 15, 15, 'JPG');
$pdf->setFont('Arial', 'B', 8);
$pdf->Cell(50, -5, utf8_decode($config['nombre']), 0, 1, 'R');
$pdf->setFont('Arial', 'B', 8);
$pdf->Cell(90, 15, 'FACTURA DE VENTA No.'. number_format( $total, 2, '.', ','), 0, 1, 'R');
$pdf->setFont('Arial', 'B', 5);
$pdf->Cell(20, 20, utf8_decode('Actividad Económica:'), 0, 0, 'L');
$pdf->setFont('Arial', 'B', 7);
$pdf->Cell(38, 4, utf8_decode('Razón Social:').utf8_decode($config['nombre']), 0, 1, 'R');
$pdf->setFont('Arial', 'B', 7);
$pdf->Cell(53.5, 3, utf8_decode('Identificación:').utf8_decode($config['ruc']), 0, 1, 'R');
$pdf->setFont('Arial', 'B', 7);
$pdf->Cell(47,4, utf8_decode('Telefóno:').utf8_decode($config['telefono']), 0, 1, 'R');
$pdf->setFont('Arial', 'B', 7);
$pdf->Cell(53,4 , utf8_decode('Dirección:').utf8_decode($config['direccion']), 0, 1, 'R');
$pdf->setFont('Arial', 'B', 7);
$pdf->Cell(52,4 , utf8_decode('Condición IVA: No aplica'), 0, 1, 'R');
$pdf->setFont('Arial', 'B', 8);
$pdf->Cell(80,-34, utf8_decode('Fecha de pago:'), 0, 1, 'R');
$pdf->setFont('Arial', 'B', 8);
$pdf->Cell(79.5,40, utf8_decode('Fecha de Vcto:'), 0, 1, 'R');

$pdf->setFont('Arial', '', 5);
$pdf->Cell(-20, -25, utf8_decode('8299 - Otras actividades'), 0, 0, 'L');
$pdf->setFont('Arial', '', 5);
$pdf->Cell(40,-20, utf8_decode('de servicio de apoyo'), 0, 1, 'R');
$pdf->setFont('Arial', '', 5);
$pdf->Cell(20,24, utf8_decode('a las empresas n.c.p'), 0, 1, 'R');
$pdf->Cell(70,-15, ('_________________________________________________________________________________'), 0, 1);
$pdf->setFont('Arial', 'B', 8);
$pdf->Cell(-20, 26, 'Sr.(es):  '.utf8_decode($cliente['nombre']), 0, 0, 'L');
$pdf->setFont('Arial', 'B', 8);
$pdf->Cell(49, 34, utf8_decode('Dirección:   ').utf8_decode($cliente['direccion']), 0, 0, 'R');
$pdf->setFont('Arial', 'B', 8);
$pdf->Cell(0.3, 42, utf8_decode('Municipio: Colombia'), 0, 0, 'R');
$pdf->setFont('Arial', 'B', 8);
$pdf->Cell(40, 25, utf8_decode('Nit:    ').utf8_decode($cliente['ruc']), 0, 0, 'R');
$pdf->setFont('Arial', '', 8);
$pdf->Cell(70,50, ('_______________________________________________________________________________________________________'), 0, 1,'R');
$pdf->setFont('Arial', 'B', 11 );

$pdf->Cell(58, -40, utf8_decode('Detalle del pedido'), 0, 0, 'R');
$pdf->Ln(-10);
$pdf->setFont('Arial', '', 9);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(45, 5, utf8_decode('Descripción'), 1, 0, 'L', 1);
$pdf->Cell(10, 5, 'Cant.', 1, 0, 'L', 1);
$pdf->Cell(15, 5, 'Precio', 1, 0, 'L', 1);
$pdf->Cell(20, 5, 'Sub Total', 1, 1, 'L', 1);

foreach ($data as $compras) {
    $subtotal = $compras['cantidad'] * $compras['precio'];
    $total = $total + $subtotal;
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(45, 5, utf8_decode($compras['producto']), 0, 0, 'L');
    $pdf->Cell(10, 5, $compras['cantidad'], 0, 0, 'L');
    $pdf->Cell(15, 5, $compras['precio'], 0, 0, 'L');
    $pdf->Cell(20, 5, number_format($subtotal, 2, '.', ','), 0, 1, 'L');
}
$pdf->Ln();
$pdf->setFont('Arial', 'B', 9);
$pdf->Cell(90, 5, 'Total:'. number_format( $total, 2, '.', ','), 0, 1, 'R');

$pdf->Output();
?>
